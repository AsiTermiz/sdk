export interface DisconnectRpcRequest {
    method: 'disconnect';
    params: [];
    id: string;
}
