export enum CHAIN {
    MAINNET = '-239',
    TESTNET = '-3'
}
