export type RpcMethod = 'disconnect' | 'sendTransaction' | 'signData';
