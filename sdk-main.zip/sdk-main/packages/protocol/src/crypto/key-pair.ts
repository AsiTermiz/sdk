export interface KeyPair {
    publicKey: string;
    secretKey: string;
}
