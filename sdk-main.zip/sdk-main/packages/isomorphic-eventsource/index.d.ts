declare type _EventSource = EventSource;
declare const _EventSource: typeof EventSource;
export = _EventSource;
