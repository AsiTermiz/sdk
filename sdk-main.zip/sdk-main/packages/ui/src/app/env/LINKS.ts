export const LINKS = {
    GET_A_WALLET:
        'https://ton.org/wallets?filters[wallet_features][slug][$in]=dapp-auth&pagination[limit]=-1'
};
