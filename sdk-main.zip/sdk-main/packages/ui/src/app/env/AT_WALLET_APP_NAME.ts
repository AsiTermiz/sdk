export const AT_WALLET_APP_NAME = 'telegram-wallet';
