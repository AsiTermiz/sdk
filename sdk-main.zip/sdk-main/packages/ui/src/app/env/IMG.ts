export const IMG = {
    TON: 'https://raw.githubusercontent.com/ton-connect/sdk/main/assets/ton-icon-48.png',
    TG: 'https://raw.githubusercontent.com/ton-connect/sdk/main/assets/tg.png'
};
