import { createContext } from 'solid-js';
import { TonConnectUI } from 'src/ton-connect-ui';

export const TonConnectUiContext = createContext<TonConnectUI>();
