export interface WithDataAttributes {
    [key: `data-${string}`]: string;
}
