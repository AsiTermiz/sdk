export interface Styleable {
    class?: string;
}
