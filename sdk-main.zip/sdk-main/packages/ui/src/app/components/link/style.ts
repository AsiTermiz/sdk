import { styled } from 'solid-styled-components';

export const AStyled = styled.a`
    display: block;
    text-decoration: unset;
`;
